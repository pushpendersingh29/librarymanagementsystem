#ifndef LIBMANAGER_H
#define LIBMANAGER_H
#include<vector>
#include "book.hpp"
using namespace std;

/********************************** class LibManager **************************/
class LibManager
{

vector<book> books;

public :
	LibManager();
	bool addBook(book b);
	void showBook();
	bool deleteBook(int bookid);
	bool updateBook(int bookid,int numc);
	bool issueBook(int bookid);
	bool returnBook(int bookid);
	~LibManager();
};
#endif
