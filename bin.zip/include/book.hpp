#ifndef BOOK_H
#define BOOK_H

/********************************** Class book *********************************************/
class book
{
	int book_id;
	char book_name[50];
	char author_name[20];
	char book_publisher[40];
	int total_copies;
public :
	bool setBookData(int bid, const char *bname, const char *aname, const char *pubisher, int tcopy);
	bool showBookData();
	bool viewBookData();
	int getBookID();
	char * getBookName();
	char * getAuthorName();
	char * getPublisherName();
	int getCopies();
	void setCopies(int);
};
#endif
