//*************include header files**************************//
#include<iostream>
#include "../include/libmanager.hpp"
#include "../include/book.hpp"

using namespace std;

/*****************************************************************
** Function Name : main
** Description : This function will show menu of LMS 
*****************************************************************/

int main()
{
	int bookid=0,numc=0;
	cout<<"------------------------------------------"<<endl;
	cout<<"\tLIBRARY MANAGEMENT SYSTEM"<<endl;
	cout<<"------------------------------------------"<<endl;
	int choice=0;
	book b;
	LibManager lmanager;
	while(true)
	{
		cout<<"\t1. DISPLAY BOOK COLLECTION"<<endl;
		cout<<"\t2. ADD BOOK"<<endl;
		cout<<"\t3. DELETE BOOK"<<endl;
		cout<<"\t4. UPDATE BOOK"<<endl;
		cout<<"\t5. ISSUE BOOK"<<endl;
		cout<<"\t6. RETURN BOOK"<<endl;
		cout<<"\t0. QUIT"<<endl;
		cout<<"Enter Choice : ";
		cin>>choice;
		cout<<"------------------------------------------"<<endl;


		switch(choice)
		{
			case 1:
				lmanager.showBook();
				break;
			case 2:
				int book_id;
				char book_name[50];
				char author_name[20];
				char book_publisher[40];
				int total_copies;
				cout<<"ADD NEW BOOK DETAILS"<<endl;
				cout<<"\tEnter Book ID :: ";
				cin>>book_id;
				cin.ignore();
				cout<<"\tEnter Book Name : ";
				cin.getline(book_name,sizeof(book_name));	
				cout<<"\tEnter Author Name : ";
				cin.getline(author_name,sizeof(author_name));
				cout<<"\tEnter Publisher Name :";
				cin.getline(book_publisher,sizeof(book_publisher));
				cout<<"\tEnter Book Copies :";
				cin>>total_copies;
				b.setBookData(book_id,book_name,author_name,book_publisher,total_copies);
			
				if(lmanager.addBook(b))
				{
					cout<<"New book added successfully"<<endl;
					cout<<"------------------------------------------"<<endl;
				}
				else
				{
					cout<<"Adding book failed, employee exist with same id"<<endl;
					cout<<"------------------------------------------"<<endl;
				}
				break;
			case 3:
				cout<<"DELETE A BOOK"<<endl;
				cout<<"\tEnter the book id to Delete : ";
				cin>>bookid;
				if(lmanager.deleteBook(bookid))
				{
					cout<<"Book with book id - "<<bookid<<" found and deleted"<<endl;
					cout<<"------------------------------------------"<<endl;					
				}
				else
				{
					cout<<"Book with book id - "<<bookid<<" not found "<<endl;	
					cout<<"------------------------------------------"<<endl;				
				}
					
				break;
			case 4:
				cout<<"UPDATE BOOK DETAILS"<<endl;
				cout<<"\tEnter the book id to Update : ";
				cin>>bookid;
				cout<<"\tUpdate the number of copies : ";
				cin>>numc;
				if(lmanager.updateBook(bookid,numc))
				{
					cout<<"Book with book id - "<<bookid<<" found and updated"<<endl;
					cout<<"------------------------------------------"<<endl;
				}					
				else
				{
					cout<<"Book with book id - "<<bookid<<" not found "<<endl;
					cout<<"------------------------------------------"<<endl;	
				}				
					
				break;
			case 5:
				cout<<"ISSUE A BOOK"<<endl;
				cout<<"\tEnter the book id to Issue : ";
				cin>>bookid;
				if(lmanager.issueBook(bookid))
				{
					cout<<"Book with book id - "<<bookid<<" found and issued"<<endl;
					cout<<"------------------------------------------"<<endl;					
				}
				else
				{
					cout<<"Book with book id - "<<bookid<<" can't issued "<<endl;		
					cout<<"------------------------------------------"<<endl;			
				}
					
				break;
			case 6:
				cout<<"RETURN A BOOK"<<endl;
				cout<<"\tEnter the book id to Return : ";
				cin>>bookid;
				if(lmanager.returnBook(bookid))
				{
					cout<<"Book with book id - "<<bookid<<" found and returned"<<endl;	
					cout<<"------------------------------------------"<<endl;				
				}
				else
				{
					cout<<"Book with book id - "<<bookid<<" not found "<<endl;
					cout<<"------------------------------------------"<<endl;					
				}
					
				break;
			case 0:
				cout<<"Exit from LMS application"<<endl;
				break;
			default:
				cout<<"Invalid Choice"<<endl;
		}//end of switch
		if(choice==0)
			break;
	}//end of while
	return 0;
}//end of main
