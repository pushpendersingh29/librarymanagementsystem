/************************ Include header ******************/
#include "../include/book.hpp"
#include "../include/libmanager.hpp"
#include<iostream>
#include<fstream>


/*****************************************************************
** Function Name : LibManager()
** Description : This is constructor function for set data into file
*****************************************************************/
LibManager::LibManager()
{
	int book_id;
 	char book_name[50];
	char author_name[20];
	char book_publisher[40];
	int total_copies;
	book b;
	ifstream in("../data/inventory.txt");
	while(!in.eof())
	{
		in>>book_id;
		in>>book_name;
		in>>author_name;
		in>>book_publisher;
		in>>total_copies;
		if(in.eof())
			break;
		b.setBookData(book_id,book_name,author_name,book_publisher,total_copies);
		books.push_back(b);
	}
	in.close();
}

/*****************************************************************
** Function Name : ~LibManager()
** Description : This is destructor function for book data
*****************************************************************/
LibManager::~LibManager()
{
	//cout<<"Destructror"<<endl;
	ofstream out("../data/inventory.txt");
	for(book &b: books)
	{
		out<<b.getBookID()<<" "<<b.getBookName()<<" "<<b.getAuthorName()<<" "<<b.getPublisherName()<<" "<<b.getCopies()<<endl;
	}
	out.close();
}


/*****************************************************************
** Function Name : addBook()
** Description : This function will use for add new book detail
*****************************************************************/
bool LibManager::addBook(book b)
{
	for(book &bk:books)
	{
		if(b.getBookID() == bk.getBookID())
			return false;	
	}
	books.push_back(b);
	return true;
	
}

/*****************************************************************
** Function Name : showBook()
** Description : This function will show book details
*****************************************************************/
void LibManager::showBook()
{
	cout<<"\tDispalying Books Details"<<endl;
	cout<<"------------------------------------------"<<endl;
	cout<<"Book ID"<<"|"<<"Book Name"<<"|"<<"Author Name"<<"|"<<"Publisher"<<"|"<<"Total Copies"<<endl;
	for(book &b : books)
		b.showBookData();
	cout<<"------------------------------------------"<<endl;
}

/*****************************************************************
** Function Name : deleteBook()
** Description : This function will delete detail of book
*****************************************************************/
bool LibManager::deleteBook(int bookid)
{
	for(auto it=books.begin();it!=books.end();it++)
	{
	if((*it).getBookID() == bookid)
		{
			cout<<"Book details are : "<<endl;
			(*it).viewBookData();

			books.erase(it);
			return true;
		}
	}
	return false;
}

/*****************************************************************
** Function Name : issueBook()
** Description : This function will issue book from library
*****************************************************************/
bool LibManager::issueBook(int bookid)
{
	for(auto it=books.begin();it!=books.end();it++)
	{
		if((*it).getBookID() == bookid)
		{
			if((*it).getCopies()>0)
			{
			cout<<"Before issuing book , book details are : "<<endl;
			(*it).viewBookData();
			cout<<"------------------------------------------"<<endl;
			(*it).setCopies((*it).getCopies()-1);
			cout<<"After issuing book , book details are : "<<endl;
			(*it).viewBookData();
			cout<<"------------------------------------------"<<endl;
			return true;
			}
			else
			{
				cout<<"Book is out of stock"<<endl;
			}
		}
	}
	return false;
}

/*****************************************************************
** Function Name : returnBook()
** Description : This function will return book in library
*****************************************************************/
bool LibManager::returnBook(int bookid)
{
	for(auto it=books.begin();it!=books.end();it++)
	{
		if((*it).getBookID() == bookid)
		{
			cout<<"Before returning book , book details are : "<<endl;
			(*it).viewBookData();
			cout<<"------------------------------------------"<<endl;
			(*it).setCopies((*it).getCopies()+1);
			cout<<"After returning book , book details are : "<<endl;
			(*it).viewBookData();
			cout<<"------------------------------------------"<<endl;
			return true;
		}
	}
	return false;
}


/*****************************************************************
** Function Name : updateBook()
** Description : This function will update detail of book
*****************************************************************/
bool LibManager::updateBook(int bookid,int numc)
{
	for(auto it=books.begin();it!=books.end();it++)
	{
		cout<<"Before updating book , book details are : "<<endl;
			(*it).viewBookData();
		cout<<"------------------------------------------"<<endl;
		if((*it).getBookID() == bookid)
		{
			(*it).setCopies(numc);
			cout<<"After updating book , book details are : "<<endl;
			(*it).viewBookData();
			cout<<"------------------------------------------"<<endl;	
			return true;
		}
	}
	return false;
}
