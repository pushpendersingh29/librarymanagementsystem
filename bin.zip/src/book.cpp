/********************* Include header files *******************************/
#include "../include/book.hpp"
#include<string.h>
#include<iostream>
using namespace std;

/*****************************************************************
** Function Name : setBookData()
** Description : This function will set the data of book
*****************************************************************/
bool book::setBookData(int bid, const char *bname, const char *aname, const char *pubisher, int tcopy)
{
	this->book_id=bid;
	strcpy(this->book_name,bname);
	strcpy(this->author_name,aname);
	strcpy(this->book_publisher,pubisher);
	this->total_copies=tcopy;
	return true;
}

/*****************************************************************
** Function Name : showBookData()
** Description : This function will display collection of all books.
*****************************************************************/
bool book::showBookData()
{
	cout<<this->book_id<<"|"<<this->book_name<<"|"<<this->author_name<<"|"<<this->book_publisher<<"|"<<this->total_copies<<endl;
	return true;
}

/*****************************************************************
** Function Name : viewBookData()
** Description : This function will display particular book detail.
*****************************************************************/
bool book::viewBookData()
{
	cout<<"Book ID : "<<this->book_id<<endl;
	cout<<"Book Name : "<<this->book_name<<endl;
	cout<<"Author Name :"<<this->author_name<<endl;
	cout<<"Book Publisher :"<<this->book_publisher<<endl;
	cout<<"Total Copies : "<<this->total_copies<<endl;
	return true;
}

/*****************************************************************
** Function Name : getBookID()
** Description : This function will return book id
*****************************************************************/
int book::getBookID()
{
	return book_id;
}

/*****************************************************************
** Function Name : getBookName()
** Description : This function will return book name
*****************************************************************/
char * book::getBookName()
{
	return book_name;
}

/*****************************************************************
** Function Name : getAuthorName()
** Description : This function will return author name
*****************************************************************/
char * book::getAuthorName()
{
	return author_name;
}

/*****************************************************************
** Function Name : getPublisherName()
** Description : This function will return publisher name
*****************************************************************/
char * book::getPublisherName()
{
	return book_publisher;
}

/*****************************************************************
** Function Name : getCopies()
** Description : This function will return total copies
*****************************************************************/
int book::getCopies()
{
	return total_copies;
}

/*****************************************************************
** Function Name : setCopies()
** Description : This function will update the total copies count
*****************************************************************/
void book::setCopies(int numcopies)
{
	total_copies=numcopies;
}
